"""Audit both frozen candidate submissions against pre-output AI source probes.
Run from repository root: .venv/bin/python runs/two-agent-comparison-20261106/judge/evaluate.py
Requires existing Pillow/numpy/shapely. This is not human/dense image truth.
"""
import json
from pathlib import Path
from PIL import Image, ImageDraw
from shapely.geometry import Polygon, Point, box
from shapely.ops import unary_union

ROOT = Path('runs/two-agent-comparison-20261106')
BENCH = Path('benchmarks/two-agent-comparison-v1')
protocol = json.loads((BENCH / 'protocol.json').read_text())
reference = json.loads((BENCH / 'judge-reference.json').read_text())
source = Image.open(protocol['source']['path']).convert('RGB')
results, geometries = {}, {}
for method in ['traditional', 'sam']:
    folder = ROOT / method
    data = json.loads((folder / 'geometry.json').read_text())
    timings = json.loads((folder / 'timing.json').read_text())
    case_map = {c['id']: c for c in data['cases']}
    method_rows, geometries[method] = [], {}
    for case in protocol['cases']:
        scope = box(*case['bounds'])
        objects = {o['id']: o for o in case_map[case['id']]['objects']}
        expected_ids = {o['id'] for o in case['targets']}
        assert set(objects) == expected_ids, (method, case['id'], set(objects), expected_ids)
        for oid, obj in objects.items():
            polygons = [Polygon(p) for p in obj['polygons']]
            assert all(p.is_valid and p.area > 0 for p in polygons), (method, oid)
            geom = unary_union(polygons)
            geometries[method][oid] = geom
            ref = reference['checks'][oid]
            positive = [geom.covers(Point(*p)) for p in ref['positive']]
            negative = [geom.covers(Point(*p)) for p in ref['negative']]
            method_rows.append({
                'case':case['id'], 'id':oid, 'polygon_valid':True,
                'outside_crop_area':geom.difference(scope).area,
                'positive_probes_hit':sum(positive), 'positive_probe_count':len(positive),
                'negative_probes_hit':sum(negative), 'negative_probe_count':len(negative),
                'positive_hits':positive, 'negative_hits':negative,
                'vertices':sum(len(p) for p in obj['polygons']),
                'area_px2':geom.area, 'component_count':len(polygons),
                'end_states':obj.get('end_states'), 'uncertainties':obj.get('uncertainties')})
    results[method] = {'timing_as_submitted':timings, 'objects':method_rows,
        'C1_C2_gap_px':geometries[method]['C1'].distance(geometries[method]['C2']),
        'C1_C2_intersection_area':geometries[method]['C1'].intersection(geometries[method]['C2']).area}

# Independent unified renderer: same native frame, same scale, same opacity.
for case in protocol['cases']:
    x0,y0,x1,y1 = case['bounds']
    raw = source.crop(case['bounds'])
    tile_w,tile_h = max(320,raw.width*3),raw.height*3+40
    out = Image.new('RGB',(tile_w*3,tile_h),'white')
    draw = ImageDraw.Draw(out)
    for idx, method in enumerate(['raw','traditional','sam']):
        tile = raw.convert('RGBA')
        if method != 'raw':
            overlay = Image.new('RGBA', raw.size)
            od = ImageDraw.Draw(overlay)
            for t in case['targets']:
                geom = geometries[method][t['id']]
                parts = list(geom.geoms) if hasattr(geom,'geoms') else [geom]
                for poly in parts:
                    pts = [(x-x0,y-y0) for x,y in poly.exterior.coords]
                    od.polygon(pts,fill=(0,210,140,85),outline=(255,80,0,255))
            tile = Image.alpha_composite(tile,overlay)
        out.paste(tile.convert('RGB').resize((raw.width*3,raw.height*3)), (idx*tile_w,40))
        draw.text((idx*tile_w+8,12),case['id']+' / '+method,fill='black')
    out.save(ROOT/'judge'/f'{case["id"]}-comparison.png')
report = {'kind':'independent_AI_reviewer_diagnostics',
    'limits':'Sparse probes and visual review are AI assessment, not human ground truth or dense accuracy. Single trial per method.',
    'results':results}
(BENCH/'evaluation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
