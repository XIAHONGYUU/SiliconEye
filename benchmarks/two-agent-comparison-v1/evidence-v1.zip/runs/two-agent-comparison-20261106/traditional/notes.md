# Traditional visual/manual branch — candidate only

Completed the three protocol crops and four specified targets from native m2.jpg. Source SHA-256 matched the protocol. Only the protocol, project AGENTS.md and native source were read; no old geometry, review answers, other branch output or main-agent assessment was consulted. No recognition, segmentation, edge detection, thresholding or automatic contour extraction was used.

One prior launch failed because of quota before a valid trial existed. That failed launch is excluded from this trial timing. Current trial starts at the actual first command on 2026-11-06 at 06:58:44 UTC.

## Procedure and limits

Viewed 4x crop images and 5x coordinate-grid images, manually specified native-coordinate polygons, rendered outlines, then visually inspected all three overlays. No geometry correction after the initial overlay inspection was needed (0 of the allowed 2 correction rounds). Grid/source images are inspection aids. The repeatable render script consumes the hand-authored geometry.json; it does not recreate the human/model visual judgment.

A1 has a candidate closed top and lower crop exit; B1 has an upper crop exit and closed right short head. C1 and C2 are separate candidate silhouettes, with their local gap preserved. The left context in C was excluded. No holes, cross-layer interpretation, or network were inferred. Blurred edges and periodic image texture leave approximately 2–3 native pixels of subjective boundary uncertainty; that estimate is not a measured confidence interval. Straight edges and bevels approximate visible material rather than tracking each intensity ripple.

## Verification

checks.json records all four polygons valid, positive-area, inside the assigned crop and containing the assigned anchor. C1/C2 are disjoint; their candidate polygon distance is approximately 24.76 pixels. This number describes manually drafted geometry, not a confirmed physical spacing. All three overlays were visually inspected against the crops. SVG XML parsing and Python syntax checks passed. These checks are not physical, electrical or human acceptance.

## Reproduction

From repository root:

```bash
.venv/bin/python runs/two-agent-comparison-20261106/traditional/render.py
```

Outputs: geometry.json, A/overlay.png and A/geometry.svg (likewise B and C), checks.json, render.py, timing.json, and these notes. Status: completed candidate delivery; no formal approval supplied. Timing stages are wall-clock intervals. Reading and manual visual reasoning are combined, and rendering/code/first inspection cannot be precisely separated inside their 19-second recorded interval; no unsupported precise inference timing is claimed.
