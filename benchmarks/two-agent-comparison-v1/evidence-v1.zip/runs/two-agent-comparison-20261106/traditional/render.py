#!/usr/bin/env python3
"""Render manually specified native-coordinate candidates and check geometry.

Run from repository root: .venv/bin/python runs/two-agent-comparison-20261106/traditional/render.py
Requires Pillow and Shapely; performs no image recognition or contour extraction.
"""
import hashlib
import json
from pathlib import Path
from PIL import Image, ImageDraw
from shapely.geometry import Point, Polygon, box

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
protocol = json.loads((ROOT / 'benchmarks/two-agent-comparison-v1/protocol.json').read_text())
source = ROOT / protocol['source']['path']
assert hashlib.sha256(source.read_bytes()).hexdigest() == protocol['source']['sha256']
photo = Image.open(source).convert('RGB')
geometry = json.loads((OUT / 'geometry.json').read_text())
report = {'status': 'candidate', 'method': 'manual_visual_native_polygon', 'cases': []}
colors = ['#ff6028', '#00ccec']
for case, spec in zip(geometry['cases'], protocol['cases'], strict=True):
    assert case['id'] == spec['id']
    x0, y0, x1, y1 = spec['bounds']
    folder = OUT / case['id']
    folder.mkdir(exist_ok=True)
    overlay = photo.crop(spec['bounds']).resize(((x1-x0)*4, (y1-y0)*4))
    draw = ImageDraw.Draw(overlay)
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{x0} {y0} {x1-x0} {y1-y0}" width="{(x1-x0)*4}" height="{(y1-y0)*4}">', f'<rect x="{x0}" y="{y0}" width="{x1-x0}" height="{y1-y0}" fill="white"/>']
    check = {'id': case['id'], 'objects': []}
    shapes = []
    for i, (obj, target) in enumerate(zip(case['objects'], spec['targets'], strict=True)):
        assert obj['id'] == target['id']
        for vertices in obj['polygons']:
            shape = Polygon(vertices)
            assert shape.is_valid and shape.area > 0
            assert box(*spec['bounds']).covers(shape)
            assert shape.covers(Point(target['anchor']))
            shapes.append(shape)
            points = [((x-x0)*4, (y-y0)*4) for x,y in vertices]
            draw.line(points + points[:1], fill=colors[i], width=3)
            anchor = target['anchor']
            draw.text(((anchor[0]-x0)*4+4, (anchor[1]-y0)*4), obj['id'], fill=colors[i])
            xy = ' '.join(f'{x},{y}' for x,y in vertices)
            svg.append(f'<polygon points="{xy}" fill="{colors[i]}" fill-opacity="0.25" stroke="{colors[i]}" stroke-width="0.65"/>')
            check['objects'].append({'id': obj['id'], 'valid': True, 'area_px2': shape.area, 'anchor_inside': True, 'within_crop': True})
    if len(shapes) == 2:
        check['candidate_gap_px'] = shapes[0].distance(shapes[1])
        assert shapes[0].disjoint(shapes[1])
    svg.append('</svg>')
    overlay.save(folder / 'overlay.png')
    (folder / 'geometry.svg').write_text('\n'.join(svg))
    report['cases'].append(check)
(OUT / 'checks.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
