# SAM-assisted candidate delivery

Completed 3 cases / 4 target external vector outlines, all **candidate**, native source coordinates. No human approval, holes, cross-layer or network conclusions. Source hash verified against protocol. Read only protocol, project AGENTS, specified SAM calling code, checkpoint, and native source; no prior geometry or other branch outputs.

Reproduce from project root:

```bash
.venv/bin/python runs/two-agent-comparison-20261106/sam/run.py
```

Existing SAM2 installation is a sunk environment cost, not included. CPU 2 threads, fixed seed 0, tiny checkpoint, no SAM postprocessing, max hole/sprinkle areas 0. Local prompts and box for each target appear in `prompts.json`. Raw masks are retained under each case. SVG uses crop-local viewBox; geometry.json uses full-image native pixels.

## Observations and correction

- First visual check: all four intended targets selected; A includes periodic texture-driven notches/long edge incursions. B's thin stem and right head, C's bent segment and independent lower segment remain visible.
- First geometry check found A ring self-intersection with epsilon 1.5 px. One explicit parameter correction: A simplification epsilon raised to 3 px (others remain 1.5). No manual mask edits, morphological fill, closing, or vertex editing. First geometry and timing retained as `geometry-round1.json` and `algorithm-timing-round1.json`.
- Second visual check of corrected A: major target envelope preserved; surface-texture-driven edge notches remain, so this is an approximate optical envelope, not a confident material boundary. No second correction.
- `RETR_EXTERNAL` intentionally delivers external envelopes without interpreting internal texture as holes. Raw masks remain unchanged. Degenerate external components reducing below three vertices are omitted from polygon output (A: 11, B: 3, C1: 4, C2: 0). This is vector degeneracy handling, not physical deletion of verified features.
- A bottom and B top touch crop boundaries; continuation outside the case remains unknown. A upper cap and B short right head appear terminated within the crop. C target outer boundaries are within the crop and separated; candidate-vector minimum gap is 25.495 px, not a calibrated physical spacing. Left out-of-bounds C context was excluded as required.

## Checks and remaining limits

`validation.json`: all four polygons have positive area, valid non-self-intersecting topology, and cover their protocol anchors; C1/C2 are disjoint. Native overlay PNGs are enlarged 4x without changing coordinate geometry. Inspection: one complete visual round followed by one corrected-A check. No formal accuracy score or comparison to another method. SAM predicted quality is explicitly not accuracy. Boundary ambiguity, texture-dependent contour detail and single-chip/single-pair scope remain unresolved. Re-run overwrites branch outputs only and does not overwrite experimental total timing.

Timing segments include all branch work; initial read/image/prompt/code effort is combined, and later inspection/correction/delivery are combined because individual tool/thinking intervals were not independently instrumented. Exact model load, encoding, decoding and vectorization durations for both runs are retained separately.
