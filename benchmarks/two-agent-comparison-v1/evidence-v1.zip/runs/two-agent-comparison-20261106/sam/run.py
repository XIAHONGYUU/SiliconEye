"""Reproduce SAM candidate external contours; run with project .venv/bin/python this_file.
Requires existing SAM2 tiny checkpoint, torch, OpenCV, Pillow; no network or source edits.
"""
from pathlib import Path
import json, time, hashlib
from datetime import datetime, timezone
import cv2
import numpy as np
import torch
from sam2.build_sam import build_sam2
from sam2.sam2_image_predictor import SAM2ImagePredictor
ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PROTOCOL = ROOT/'benchmarks/two-agent-comparison-v1/protocol.json'
CKPT = ROOT/'runs/metal-algorithm-pilot-20261106/models/sam2.1_hiera_tiny-hf.pt'
def utc(): return datetime.now(timezone.utc).isoformat()
def write(name, data): (OUT/name).write_text(json.dumps(data, indent=2)+'\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
# Prompts manually selected from native source crops, expressed in crop-local pixels.
PROMPTS = {
 'A1': {'positive': [[44,60],[44,130],[44,230],[44,310]], 'negative': [[20,130],[72,130],[43,29]], 'box':[27,42,63,320]},
 'B1': {'positive': [[40,10],[40,62],[42,98],[58,101]], 'negative': [[23,60],[62,60],[49,122]], 'box':[32,0,73,111]},
 'C1': {'positive': [[96,45],[120,45],[121,73]], 'negative': [[76,45],[102,76],[144,70],[121,100]], 'box':[85,30,138,94]},
 'C2': {'positive': [[49,82],[59,95]], 'negative': [[32,86],[80,89],[52,62],[53,116]], 'box':[36,68,73,114]},
}
start=utc(); total=time.perf_counter(); torch.set_num_threads(2);torch.manual_seed(0);cv2.setNumThreads(2);cv2.setRNGSeed(0)
protocol=json.loads(PROTOCOL.read_text());source=ROOT/protocol['source']['path']
assert sha(source)==protocol['source']['sha256']
raw=cv2.imread(str(source)); tick=time.perf_counter()
model=build_sam2('configs/sam2.1/sam2.1_hiera_t.yaml',str(CKPT),device='cpu',apply_postprocessing=False)
predictor=SAM2ImagePredictor(model,max_hole_area=0,max_sprinkle_area=0)
times={'model_load_seconds':time.perf_counter()-tick,'cases':[]}
result={'status':'candidate','source':protocol['source'],'coordinate_frame':'native source pixels','cases':[]}
write('prompts.json',{'coordinate_frame':'crop-local pixels','prompts':PROMPTS,'manual_corrections':[{'round':1,'object':'A1','change':'Increase contour simplification epsilon from 1.5 to 3 native px after ring self-intersection; raw mask unchanged.'}], 'configuration':{'model':'sam2.1_hiera_tiny','threads':2,'seed':0,'apply_postprocessing':False,'max_hole_area':0,'max_sprinkle_area':0,'simplification_epsilon_native_px':{'A1':3,'default':1.5}}})
for case in protocol['cases']:
 x0,y0,x1,y1=case['bounds'];crop=raw[y0:y1,x0:x1];h,w=crop.shape[:2]
 d=OUT/case['id'];d.mkdir(exist_ok=True);cv2.imwrite(str(d/'source.png'),crop)
 tick=time.perf_counter()
 with torch.inference_mode(): predictor.set_image(cv2.cvtColor(crop,cv2.COLOR_BGR2RGB))
 encoding=time.perf_counter()-tick;entry={'id':case['id'],'objects':[]};overlay=crop.copy();svg=[];ot=[]
 for target in case['targets']:
  ident=target['id'];p=PROMPTS[ident];tick=time.perf_counter()
  with torch.inference_mode():
   masks,scores,_=predictor.predict(point_coords=np.array(p['positive']+p['negative']),point_labels=np.array([1]*len(p['positive'])+[0]*len(p['negative'])),box=np.array(p['box']),multimask_output=False)
  inference=time.perf_counter()-tick;mask=masks[0].astype(np.uint8)*255;cv2.imwrite(str(d/f'{ident}-raw-mask.png'),mask)
  tick=time.perf_counter();contours,hierarchy=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  # Keep all external components: no size filtering, morphological fill, or manual geometry edits.
  polys=[];ends=[]
  for contour in contours:
   poly=cv2.approxPolyDP(contour,3.0 if ident=='A1' else 1.5,True).reshape(-1,2)
   if len(poly)<3: continue
   native=poly+np.array([x0,y0]);polys.append(native.tolist())
   for name,condition in [('left',np.any(poly[:,0]==0)),('right',np.any(poly[:,0]==w-1)),('top',np.any(poly[:,1]==0)),('bottom',np.any(poly[:,1]==h-1))]:
    if condition: ends.append({'edge':name,'state':'clipped_by_case_bounds','continuation':'unknown_outside_crop'})
   color=(0,200,255) if ident!='C2' else (255,120,0)
   cv2.polylines(overlay,[poly.astype(np.int32)],True,color,1,cv2.LINE_AA)
   points=' '.join(f'{int(x)},{int(y)}' for x,y in poly);stroke='#ffc800' if ident!='C2' else '#0078ff'
   svg.append(f'<polygon data-object="{ident}" points="{points}" fill="none" stroke="{stroke}" stroke-width="1"/>')
  conversion=time.perf_counter()-tick
  entry['objects'].append({'id':ident,'status':'candidate','polygons':polys,'end_states':ends + ([{'location':'upper cap','state':'visible_termination'}] if ident=='A1' else [{'location':'right short head','state':'visible_termination'}] if ident=='B1' else [{'location':'all outer edges','state':'visible_termination_with_soft_optical_boundary'}]),'uncertainties':['Soft optical boundary; contour depends on prompts and mask threshold.','External envelope only; internal texture and mask voids are not interpreted as holes.'],'sam_predicted_quality_not_accuracy':float(scores[0])})
  ot.append({'id':ident,'decoding_seconds':inference,'vectorization_seconds':conversion,'external_components':len(contours),'polygons':len(polys)})
 cv2.imwrite(str(d/'overlay.png'),cv2.resize(overlay,(w*4,h*4),interpolation=cv2.INTER_NEAREST))
 (d/'geometry.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w*4}" height="{h*4}"><rect width="{w}" height="{h}" fill="#222"/>'+''.join(svg)+'</svg>')
 result['cases'].append(entry);times['cases'].append({'id':case['id'],'encoding_seconds':encoding,'objects':ot})
write('geometry.json',result)
write('algorithm-timing.json',{'start_utc':start,'end_utc':utc(),'wall_seconds':time.perf_counter()-total,'timings':times,'checkpoint_sha256':sha(CKPT)})
print(json.dumps(times,indent=2))
# Basic geometry checks are distinct from physical accuracy and human approval.
from shapely.geometry import Polygon, Point
validation={'status':'geometric_checks_only_not_physical_approval','objects':[]}
for c,pc in zip(result['cases'],protocol['cases']):
 for obj,target in zip(c['objects'],pc['targets']):
  polygon=Polygon(obj['polygons'][0])
  assert polygon.is_valid and polygon.area>0
  assert polygon.covers(Point(target['anchor']))
  validation['objects'].append({'id':obj['id'],'valid':True,'anchor_covered':True,'vertices':len(obj['polygons'][0]),'area_px2':polygon.area})
a,b=[Polygon(obj['polygons'][0]) for obj in result['cases'][2]['objects']]
validation['C1_C2_gap_native_px']=a.distance(b)
validation['C1_C2_overlap']=a.intersects(b)
write('validation.json',validation)
