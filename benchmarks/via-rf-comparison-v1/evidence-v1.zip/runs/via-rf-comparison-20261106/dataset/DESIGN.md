# V1 candidate search comparison dataset

All 11 crops originate from the same M1 image and retain native pixels. Four training crops have two region-level human-confirmed positive and two negative labels; seven anonymous test crops contain four reviewed positives and three reviewed negatives. Source identities and target boxes are private in judge/reference.json. Actual human decision hashes were verified. Training/test source rectangles do not overlap; nearby negative sites remain spatially correlated, and one-chip results do not measure cross-chip generalization.

A positive search box is not a pixel mask. Pixel annotations may be made by the algorithm agent using training images only; they must remain AI scribbles. No dense human ground truth, exact via count or physical boundary exists. The test crop context is not exhaustively adjudicated: only candidate centers inside the historical named target scopes are graded; all other candidates are unadjudicated, not false positives.

Candidate boxes must be inside the 80x128 crop, positive width/height, at most 50x80 (maximum training positive search dimensions). This excludes a whole-crop box. A VIA-status candidate center inside a positive target counts a target hit; inside an explicit negative target counts a false-target hit. UNKNOWN is abstention. This is coarse localization, not exact center or boundary accuracy.

Both branches receive identical training evidence and anonymous test images. They must preserve first outputs and declare rules/thresholds before first test predictions. No test-label feedback tuning. First complete wall time and repeated batch compute are reported separately; external quota waits are excluded and recorded.
