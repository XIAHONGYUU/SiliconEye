"""Freeze source-bound train/test crops for the V1 exploratory comparison."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "runs/via-rf-comparison-20261106"


def read(p):
    return json.loads((ROOT / p).read_text())


def evidence(p):
    f = ROOT / p
    return {"path": p, "sha256": hashlib.sha256(f.read_bytes()).hexdigest()}


source = "data/test_chip/tile_full/m1.jpg"
img = Image.open(ROOT / source).convert("RGB")
neg = read("benchmarks/w34-terminal-v1-reviewed-v2/negative-reference-set.json")
u = read("benchmarks/n2-v1-identity-reviewed-v7/reviewed-site-identities-v1.json")
abp = "benchmarks/corridor-m1-v1-reviewed-v2/human-review.json"
wp = "benchmarks/west-w2-v1-reviewed-v8/human-review.json"
items = {}
for x in neg["examples"]:
    key = x["human_item_id"]
    items[key] = {
        "source_id": x["id"],
        "label": "non_via",
        "target": x["native_search_bounds"],
        "human_review": x["human_review"],
        "human_item_id": key,
        "human_statement": x["human_note"],
    }
for x in u["reviewed_sites"]:
    items[x["id"]] = {
        "source_id": x["id"],
        "label": "via" if x["V1_present"] else "non_via",
        "target": x["source_bounds"],
        "human_review": x["human_review"],
        "human_item_id": x["id"],
        "human_statement": "V1_present=" + str(x["V1_present"]),
    }
for x in read(abp)["decisions"]:
    key = x["interface_id"][-1]
    items[key] = {
        "source_id": x["interface_id"],
        "label": "via",
        "target": x["native_bounds"],
        "human_review": evidence(abp),
        "human_item_id": x["interface_id"],
        "human_statement": "都有; A/B both V1 present",
    }
for x in read(wp)["decisions"]:
    key = x["interface_id"]
    items[key] = {
        "source_id": key,
        "label": "via",
        "target": x["native_search_bounds"],
        "human_review": evidence(wp),
        "human_item_id": key,
        "human_statement": x["statement"],
    }
train = [("R01", "A"), ("R02", "N1"), ("R03", "U1"), ("R04", "N2")]
test = [
    ("Q01", "N3"),
    ("Q02", "W2-V1-S"),
    ("Q03", "U2"),
    ("Q04", "B"),
    ("Q05", "S1"),
    ("Q06", "W2-V1-N"),
    ("Q07", "U3"),
]
public = {
    "version": 1,
    "task": (
        "Locate V1-like groups in anonymous M1 crops; reject non-via "
        "appearances or report uncertain."
    ),
    "coordinate_system": (
        "local crop pixels, x right/y down; all crops 80x128, original native resolution"
    ),
    "train": [],
    "test": [],
    "output_schema": {
        "predictions": [
            {
                "id": "Qxx",
                "decision": "via|non_via|uncertain",
                "candidates": [{"bbox": [0, 0, 1, 1], "confidence": 0.0}],
                "note": "optional explanation",
            }
        ]
    },
    "evaluation_scope": (
        "Only historical human-reviewed subregions are graded; candidate "
        "boxes outside those scopes remain unadjudicated. Whole-crop "
        "physical absence, exact cut counts and dense pixel labels are not "
        "known."
    ),
    "training_labels": (
        "Region-level via presence/absence from past human decisions; any "
        "pixel scribbles must be authored from TRAIN images and marked AI "
        "annotations, not dense human truth."
    ),
    "isolation": (
        "No historical files, source IDs/coordinates, judge files, test "
        "answers or opposite branch outputs. Test images may be "
        "inspected/predicted once parameters are frozen. No test-label "
        "feedback tuning."
    ),
    "threshold_policy": (
        "Declare decision/uncertainty thresholds and model hyperparameters "
        "before first test predictions. Preserve original predictions."
    ),
    "timing_policy": (
        "Record first complete wall time excluding external quota wait; "
        "separate setup/annotation/train/predict/review; 5 repeat batch "
        "predictions after model fixed, no test tuning."
    ),
}
private = {
    "frozen_utc": datetime.now(UTC).isoformat(),
    "source": evidence(source),
    "human_label_scope": (
        "Presence/absence within named targets only; centers/counts/boundaries not approved."
    ),
    "train": [],
    "test": [],
    "metric_plan": {
        "target_hit": (
            "At least one candidate center inside positive human search bounds. "
            "Region-level localization only, no exact center error."
        ),
        "false_target_hit": "At least one candidate center inside explicit negative search bounds.",
        "unadjudicated": (
            "Candidate center outside all named scopes for that crop. Not counted false."
        ),
        "decision": (
            "Separately grade crop decision against designated target label, "
            "noting the model does not know hidden target bounds; a positive "
            "outside target cannot make target hit."
        ),
        "rejection": "uncertain is abstention, not correct negative; report coverage.",
        "training_test_overlap": "No original pixel rectangle overlap allowed.",
    },
}
for split, seq in [("train", train), ("test", test)]:
    for ident, key in seq:
        x = dict(items[key])
        x0, y0, x1, y1 = x["target"]
        cx = (x0 + x1) // 2
        cy = (y0 + y1) // 2
        crop = [cx - 40, cy - 64, cx + 40, cy + 64]
        local = [x0 - crop[0], y0 - crop[1], x1 - crop[0], y1 - crop[1]]
        rel = f"runs/via-rf-comparison-20261106/dataset/{split}/{ident}.png"
        im = img.crop(crop)
        im.save(ROOT / rel)
        rec = {
            "id": ident,
            "image": str(ROOT / rel),
            "image_sha256": hashlib.sha256((ROOT / rel).read_bytes()).hexdigest(),
            "size": [80, 128],
        }
        if split == "train":
            rec.update(label=x["label"], reviewed_scope_bbox=local)
        public[split].append(rec)
        x.update(
            id=ident,
            crop_native=crop,
            target_local=local,
            image=rel,
            image_sha256=rec["image_sha256"],
        )
        private[split].append(x)
        assert (
            hashlib.sha256((ROOT / x["human_review"]["path"]).read_bytes()).hexdigest()
            == x["human_review"]["sha256"]
        )
for a in private["train"]:
    for b in private["test"]:
        p, q = a["crop_native"], b["crop_native"]
        assert min(p[2], q[2]) <= max(p[0], q[0]) or min(p[3], q[3]) <= max(p[1], q[1]), (
            a["id"],
            b["id"],
        )
public["output_schema"] = {
    "images": [
        {
            "id": "Qxx",
            "candidates": [
                {
                    "bbox": [0, 0, 1, 1],
                    "score": None,
                    "status": "via|unknown",
                    "reason": "optional explanation",
                }
            ],
            "note": "optional; no candidate means no detected via, not whole-crop physical absence",
        }
    ]
}
public["candidate_size_limit"] = {
    "max_width": 50,
    "max_height": 80,
    "basis": (
        "Maximum width and height of training human-reviewed positive "
        "search boxes; prevents full-crop box from counting as "
        "localization. Not true via dimensions."
    ),
}
private["metric_plan"]["target_hit"] = (
    "At least one valid VIA candidate bbox center inside positive human "
    "search bounds; bbox width<=50 and height<=80, fully inside crop. "
    "Unknown does not count hit."
)
private["metric_plan"]["false_target_hit"] = (
    "At least one valid VIA candidate bbox center inside explicit "
    "negative search bounds; unknown counted separately."
)
private["metric_plan"].pop("decision", None)
private["metric_plan"]["candidate_size_limit"] = {
    "width": 50,
    "height": 80,
    "basis": "train positive human search max dimensions",
}
private["metric_plan"]["frozen_before_predictions"] = True
(BASE / "dataset/dataset.json").write_text(json.dumps(public, ensure_ascii=False, indent=2))
(BASE / "judge/reference.json").write_text(json.dumps(private, ensure_ascii=False, indent=2))
for split in ["train", "test"]:
    rows = public[split]
    sheet = Image.new("RGB", (len(rows) * 240, 420), "white")
    d = ImageDraw.Draw(sheet)
    for i, row in enumerate(rows):
        sheet.paste(Image.open(row["image"]).resize((240, 384)), (240 * i, 36))
        d.text((240 * i + 5, 6), row["id"] + (" " + row.get("label", "")), fill="black")
    sheet.save(BASE / f"dataset/{split}-montage.png")
print(
    json.dumps(
        {
            "train": len(train),
            "test": len(test),
            "frozen_utc": private["frozen_utc"],
            "overlap": "none",
            "human_review_hashes": "all verified",
        }
    )
)
