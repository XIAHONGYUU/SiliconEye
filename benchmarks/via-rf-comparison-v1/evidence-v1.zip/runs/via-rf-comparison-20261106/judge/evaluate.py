"""Grade frozen V1 candidate outputs against scoped historical human decisions.

Run: .venv/bin/python runs/via-rf-comparison-20261106/judge/evaluate.py \
    --visual PATH --rf PATH
Requires Pillow; never updates production geometry or original branch outputs.
"""

import argparse
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from PIL import Image, ImageDraw

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inside(pt, box):
    return box[0] <= pt[0] < box[2] and box[1] <= pt[1] < box[3]


def grade(path, ref):
    payload = json.loads(path.read_text())
    rows = payload.get("images", [])
    ids = [r.get("id") for r in rows]
    known = {r["id"] for r in ref["test"]}
    if len(ids) != len(set(ids)) or set(ids) != known:
        raise ValueError(f"Expected each anonymous ID exactly once: {ids}")
    indexed = {r["id"]: r for r in rows}
    results = []
    for truth in ref["test"]:
        row = indexed[truth["id"]]
        target = truth["target_local"]
        candidates = []
        for c in row.get("candidates", []):
            b = c.get("bbox", [])
            valid = (
                len(b) == 4
                and all(isinstance(x, (float, int)) for x in b)
                and 0 <= b[0] < b[2] <= 80
                and 0 <= b[1] < b[3] <= 128
                and b[2] - b[0] <= 50
                and b[3] - b[1] <= 80
                and c.get("status") in ["via", "unknown"]
            )
            center = [(b[0] + b[2]) / 2, (b[1] + b[3]) / 2] if valid else None
            candidates.append(
                {
                    **c,
                    "valid": valid,
                    "center": center,
                    "inside_reviewed_target": inside(center, target) if valid else None,
                    "adjudication": (
                        "invalid"
                        if not valid
                        else "scoped_target"
                        if inside(center, target)
                        else "unadjudicated_context"
                    ),
                }
            )
        hits = [
            c
            for c in candidates
            if c["valid"] and c["inside_reviewed_target"] and c["status"] == "via"
        ]
        uncertain = [
            c
            for c in candidates
            if c["valid"] and c["inside_reviewed_target"] and c["status"] == "unknown"
        ]
        positive = truth["label"] == "via"
        results.append(
            {
                "id": truth["id"],
                "source_id": truth["source_id"],
                "expected_label": truth["label"],
                "target_local": target,
                "target_via_hit": bool(hits),
                "positive_hit": bool(hits) if positive else None,
                "negative_false_hit": bool(hits) if not positive else None,
                "target_unknown": bool(uncertain),
                "negative_explicit_rejection_or_no_detection": not hits and not uncertain
                if not positive
                else None,
                "candidates": candidates,
                "note": row.get("note", ""),
            }
        )
    pos = [r for r in results if r["expected_label"] == "via"]
    neg = [r for r in results if r["expected_label"] == "non_via"]
    return {
        "predictions_path": str(path),
        "predictions_sha256": digest(path),
        "metrics": {
            "positive_targets": len(pos),
            "positive_targets_hit": sum(r["positive_hit"] for r in pos),
            "positive_targets_missed": sum(not r["positive_hit"] for r in pos),
            "negative_targets": len(neg),
            "negative_targets_false_hit": sum(r["negative_false_hit"] for r in neg),
            "negative_targets_unknown_without_hit": sum(
                r["target_unknown"] and not r["target_via_hit"] for r in neg
            ),
            "negative_targets_no_hit_no_unknown": sum(
                r["negative_explicit_rejection_or_no_detection"] for r in neg
            ),
            "target_unknown_count": sum(r["target_unknown"] for r in results),
            "invalid_candidates": sum(not c["valid"] for r in results for c in r["candidates"]),
            "unadjudicated_context_candidates": sum(
                c["adjudication"] == "unadjudicated_context"
                for r in results
                for c in r["candidates"]
            ),
            "total_candidates": sum(len(r["candidates"]) for r in results),
        },
        "items": results,
    }


def render(branches, ref):
    # Each row: raw, visual, RF; same source scale and same candidate colors.
    panelw, panelh = 240, 420
    colors = {"via": "#ff3030", "unknown": "#ffb000"}
    sheet = Image.new("RGB", (panelw * 3, panelh * len(ref["test"])), "white")
    draw = ImageDraw.Draw(sheet)
    for i, truth in enumerate(ref["test"]):
        im = Image.open(ROOT / truth["image"]).convert("RGB")
        for j, name in enumerate(["source", "visual", "rf"]):
            panel = im.copy()
            if name != "source":
                pd = ImageDraw.Draw(panel)
                row = next(r for r in branches[name]["items"] if r["id"] == truth["id"])
                for c in row["candidates"]:
                    if c["valid"]:
                        pd.rectangle(c["bbox"], outline=colors[c["status"]], width=1)
            sheet.paste(panel.resize((240, 384)), (j * panelw, i * panelh + 30))
            draw.text((j * panelw + 5, i * panelh + 7), f"{truth['id']} {name}", fill="black")
    sheet.save(HERE / "comparison.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--visual", type=Path, required=True)
    ap.add_argument("--rf", type=Path, required=True)
    args = ap.parse_args()
    refpath = HERE / "reference.json"
    ref = json.loads(refpath.read_text())
    assert digest(ROOT / ref["source"]["path"]) == ref["source"]["sha256"]
    branches = {"visual": grade(args.visual, ref), "rf": grade(args.rf, ref)}
    out = {
        "evaluated_utc": datetime.now(UTC).isoformat(),
        "reference_sha256": digest(refpath),
        "scope": (
            "Human-reviewed target presence/absence only; coarse candidate localization. "
            "No dense labels or exact center/IoU accuracy."
        ),
        "branches": branches,
    }
    (HERE / "evaluation.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
    render(branches, ref)
    print(json.dumps({k: v["metrics"] for k, v in branches.items()}, indent=2))


if __name__ == "__main__":
    main()
