"""Render frozen visual predictions with project .venv Python; requires Pillow."""
import json
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path(__file__).resolve().parent
DATA = json.loads((OUT.parent / 'dataset/dataset.json').read_text())
PRED = json.loads((OUT / 'predictions.json').read_text())
by_id = {r['id']: r for r in PRED['images']}
sheet = Image.new('RGB', (7 * 260, 460), 'white')
for i, row in enumerate(DATA['test']):
    im = Image.open(row['image']).convert('RGB')
    draw = ImageDraw.Draw(im)
    result = by_id[row['id']]
    for candidate in result['candidates']:
        x0, y0, x1, y1 = candidate['bbox']
        assert 0 <= x0 < x1 <= 80 and 0 <= y0 < y1 <= 128
        assert x1-x0 <= 50 and y1-y0 <= 80
        color = '#ff3030' if candidate['status'] == 'via' else '#ffff00'
        draw.rectangle((x0,y0,x1-1,y1-1), outline=color, width=1)
    im.save(OUT / (row['id'] + '-overlay.png'))
    sheet.paste(im.resize((240,384), Image.Resampling.NEAREST), (i*260,50))
    label = ','.join(c['status'] for c in result['candidates']) or 'no candidate'
    ImageDraw.Draw(sheet).text((i*260+5,5), row['id']+' '+label, fill='black')
sheet.save(OUT / 'contact-sheet.png')
print('Rendered 7 overlays; all boxes inside image and size limits.')
