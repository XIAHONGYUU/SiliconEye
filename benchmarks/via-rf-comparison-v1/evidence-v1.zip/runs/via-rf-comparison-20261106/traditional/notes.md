# Visual blind baseline

- Scope: only project AGENTS.md, dataset.json, its 4 public training images and 7 anonymous test images, and this output directory. No historical files, source identities, evaluation answers, or other branch results were read.
- Method: direct visual interpretation after viewing labeled train montage. Decision rules are recorded in decision_policy.json before first test view. No pixel classification, thresholding, feature extraction, template matching, or inferred test-label feedback. Image code only resized, annotated and rendered manually chosen boxes.
- Frozen outcome: 4 via candidates (Q02/Q04/Q06/Q07), 1 unknown (Q03), 2 empty outputs (Q01/Q05). Every box denotes an appearance-level candidate group. No physical cut count or electrical connectivity is asserted. Empty output does not establish whole-crop absence.
- Scores are null because no calibrated confidence model exists. Unknown retains a plausible crossing that could be a stripe artifact.
- Predictions were frozen before overlay rendering. Overlay review checked coordinate placement, bounds, maximum sizes, and correspondence to frozen statuses; predictions were not changed.
- Rendering is reproducible with `.venv/bin/python runs/via-rf-comparison-20261106/traditional/render.py`. The reasoning itself is a one-pass agent visual baseline, not a deterministic rerunnable detector. Five render passes would not measure five independent visual predictions; not claimed.
- Timing includes setup failures and final artifact rendering/check, excludes waiting for dataset availability. No external quota wait occurred.
