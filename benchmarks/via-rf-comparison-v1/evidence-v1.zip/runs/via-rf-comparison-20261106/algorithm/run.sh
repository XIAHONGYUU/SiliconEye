#!/usr/bin/env bash
# Run the frozen official ilastik CPU experiment; requires extracted portable runtime.
# Usage: ./run.sh --output result-name [--model /absolute/model.ilp]
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
sha256sum -c frozen-inputs.sha256
runtime_dir="$PWD/runtime/ilastik-1.4.2-Linux"
export QT_QPA_PLATFORM=offscreen
export LAZYFLOW_THREADS=2
export LAZYFLOW_TOTAL_RAM_MB=2000
export OMP_NUM_THREADS=2
export LD_LIBRARY_PATH="$runtime_dir/lib"
export PYTHONPATH=""
export PYTHONHOME="$runtime_dir"
export PYTHONNOUSERSITE=1
export XDG_STATE_HOME="$PWD/runtime-state"
export XDG_CONFIG_HOME="$PWD/runtime-config"
export XDG_CACHE_HOME="$PWD/runtime-cache"
export QT_PLUGIN_PATH="$runtime_dir/plugins"
export FONTCONFIG_PATH="$runtime_dir/etc/fonts"
export FONTCONFIG_FILE="$runtime_dir/etc/fonts/fonts.conf"
mkdir -p "$XDG_STATE_HOME/ilastik/log" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME"
exec "$runtime_dir/bin/python" "$PWD/run_ilastik.py" "$@"
