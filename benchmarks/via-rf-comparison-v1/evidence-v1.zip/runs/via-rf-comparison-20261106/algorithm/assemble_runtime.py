"""Verify Range segments, retain prefix, assemble and test official archive."""
import hashlib,json,shutil,subprocess,time
from pathlib import Path
base=Path(__file__).resolve().parent
meta=json.loads((base/'download-parts.json').read_text())
prefix=base/'ilastik-1.4.2-Linux.tar.bz2'
assert prefix.stat().st_size==meta['prefix_bytes']
for part in meta['parts']:
 assert (base/f"runtime.part-{part['part']}").stat().st_size==part['bytes']
start=time.time()
output=base/'ilastik-1.4.2-Linux.complete.tar.bz2'
assert not output.exists()
with output.open('wb') as dst:
 for source in [prefix]+[base/f"runtime.part-{x['part']}" for x in meta['parts']]:
  with source.open('rb') as src: shutil.copyfileobj(src,dst)
assert output.stat().st_size==meta['total_bytes']
subprocess.run(['bzip2','-t',str(output)],check=True)
record={'archive_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'archive_bytes':output.stat().st_size,'integrity':'bzip2 -t passed','assembly_integrity_seconds':time.time()-start}
(base/'runtime-verification.json').write_text(json.dumps(record,indent=2))
runtime=base/'runtime';runtime.mkdir(exist_ok=True)
start=time.time();subprocess.run(['tar','-xjf',str(output),'-C',str(runtime)],check=True)
record['extraction_seconds']=time.time()-start
(base/'runtime-verification.json').write_text(json.dumps(record,indent=2))
print(record)
