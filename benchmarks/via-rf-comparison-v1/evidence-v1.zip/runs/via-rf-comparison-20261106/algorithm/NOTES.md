# Real ilastik frozen experiment

Scope: public `dataset/dataset.json`, its four TRAIN and seven TEST images,
and existing `algorithm/` files only. No judge labels, historical identities,
traditional branch, or benchmark outputs are consulted. All outputs are candidates.

The unchanged `frozen-config.json`, `annotations.json`, and `labels/` are recorded
in `frozen-inputs.sha256`. AI scribbles are not human pixel truth. No test feedback
or hyperparameter tuning is allowed.

Runtime: official CPU portable ilastik 1.4.2 from
<https://files.ilastik.org/ilastik-1.4.2-Linux.tar.bz2>.
The existing 351 MB archive was incomplete. It is resumed with HTTP Range instead
of redownloading. `ilastik-1.4.2/` is source code, not the portable runtime.
Download/DNS failures are retained in `logs/`. No global installation or upload.

Implementation follows official bundled examples and tests:
`examples/example_python_client.py` and
`tests/test_ilastik/test_applets/pixelClassification/testPixelClassificationHeadless.py`.
`run_ilastik.py` creates a real Pixel Classification project, trains the official
ParallelVigra RF using frozen scribble rasters, and saves the classifier in `.ilp`.
All six frozen features at all five frozen scales are selected, computed in 2D.
Pillow L luminance is applied consistently to train/test into derived HDF5 copies.
Raw images and frozen labels are preserved.

Component details resolving unspecified implementation choices before prediction:
SciPy default cross structure (4 connectivity) for binary closing and labeling;
component pixel count and mean include the post-closing mask; bounding boxes use
exclusive upper x/y boundaries. Components below mean 0.65 are discarded; means
0.65–0.75 are unknown; means at least 0.75 are via appearance candidates. Oversize
boxes are discarded and counted, never clipped. All thresholds come from freeze.

The probability arrays preserve float values; PNGs are display-only quantizations.
Entropy is binary Shannon entropy in bits, not calibrated physical uncertainty.
Five whole-test batch exports create/remove batch lanes, measuring feature
extraction plus prediction and batch plumbing, with the trained model held fixed.
Repeat arrays must be bitwise equal. Saved-model rerun is separately verified.

Timing: `start.txt` belongs to the interrupted attempt and is **not** used as total
active work time. Prior setup and annotation active durations are unknown. Resume
wall time, resumed download/extraction, app startup, project preparation, feature/RF
training, save, prediction, and postprocessing are separated when measurable.
Do not compare an incomplete historical total with a fully timed competing method.

Rerun commands and verified runtime/results will be appended after completion.


## Completed official-runtime execution (2026-11-08)

The already-saved `result/model.ilp` from `logs/train-third.log` was reused,
not retrained. That log records official PixelClassificationWorkflow training
with ParallelVigra RF, 100 trees and label counts (208, 1239). The logged RF
training duration is 0.088 seconds; it is the library RF-only measurement,
not feature extraction, project setup, saving, or total development time.
The log OOB value is internal training diagnostics, not TEST accuracy.
Training setup, feature-plus-training and model-save perf_counter measurements
were not flushed before the original export failure and remain unknown.

The API compatibility fix changes run_export input to a list of lane mappings,
each mapping Raw Data to FilesystemDatasetInfo. Frozen parameters, labels and
postprocessing thresholds are unchanged. No sklearn fallback was used.
`logs/train-fourth.log` retains an attempted run stopped by the existing-model
guard; the shell preparation also failed because `python` was unavailable.
`logs/predict-fifth.log` retains a relative-model-path failure after run.sh changed
working directory. Using the absolute model path resolved it.

`logs/predict-sixth.log` is the first successful complete run. Its outputs are
preserved in `result/`: seven probability and seven entropy float NPY arrays,
matching display PNGs, predictions.json, timing.json, and the trained model.ilp.
`result-reload/` contains a separate process's outputs from the same saved model;
`logs/reload.log` records that run. Each run exports all seven images five times
and checks exact array equality. `reload-verification.json` additionally checks
all 14 NPY arrays and predictions.json against the first run: PASS.
The model hash is unchanged across both process loads.

Timing files use perf_counter for app/model load, test preparation, each batch,
and postprocessing. They explicitly keep original setup/annotation and full
cross-session work duration null. Do not infer them from start.txt, file mtimes,
or continuation_start_epoch. Loading the model is included in app_start_seconds.
No inference precision/recall or physical correctness claim is made here.

Rerun (use an unused output directory; run.sh validates frozen input hashes):

```bash
./run.sh --output result-new --model /home/zuoky/project_siliconeyes/silicon-eye/runs/via-rf-comparison-20261106/algorithm/result/model.ilp
```

For a new training execution with the identical freeze, omit --model and choose
an unused output directory. The successful saved model is kept as the baseline.
Ruff check of run_ilastik.py passes. Formatting changes and strict zip length
checks do not alter model features, thresholds, or candidate calculations.
