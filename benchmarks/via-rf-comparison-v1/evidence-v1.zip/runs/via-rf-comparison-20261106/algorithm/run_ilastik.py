"""Train official ilastik from frozen scribbles, or predict with the saved model.

Run via run.sh. Requires the official portable runtime; never reads judge labels.
The first successful predictions are preserved; use a new output directory to rerun.
"""

# Runtime environment must be set before importing ilastik/numerical libraries.
# ruff: noqa: E402
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
CFG = json.loads((BASE / "frozen-config.json").read_text())
os.environ["LAZYFLOW_THREADS"] = str(CFG["threads"])
os.environ["LAZYFLOW_TOTAL_RAM_MB"] = str(CFG["ram_mb"])
os.environ["OMP_NUM_THREADS"] = str(CFG["threads"])

import h5py
import numpy as np
import vigra
from ilastik import app
from ilastik.applets.dataSelection.opDataSelection import FilesystemDatasetInfo
from lazyflow.classifiers import ParallelVigraRfLazyflowClassifierFactory
from PIL import Image
from scipy import ndimage


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def prepare(row, directory):
    source = Path(row["image"])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == row["image_sha256"]
    # Fixed standard Pillow luminance conversion, applied identically to train/test.
    gray = np.asarray(Image.open(source).convert("L"))[:, :, None]
    path = directory / (row["id"] + ".h5")
    with h5py.File(path, "w") as f:
        ds = f.create_dataset("data", data=gray)
        ds.attrs["axistags"] = vigra.defaultAxistags("yxc").toJSON()
    return str(path) + "/data"


def candidates(prob):
    mask = ndimage.binary_closing(
        prob >= CFG["pixel_foreground_threshold"],
        iterations=CFG["binary_closing_iterations"],
    )
    components, _ = ndimage.label(mask)
    result, counts = [], {"small": 0, "oversize": 0, "low_mean": 0}
    for index, slices in enumerate(ndimage.find_objects(components), 1):
        if slices is None:
            continue
        pixels = components[slices] == index
        if int(pixels.sum()) < CFG["component_min_pixels"]:
            counts["small"] += 1
            continue
        y, x = slices
        if x.stop - x.start > CFG["max_bbox_width"] or y.stop - y.start > CFG["max_bbox_height"]:
            counts["oversize"] += 1
            continue
        score = float(prob[slices][pixels].mean())
        if score < CFG["component_unknown_mean_probability"]:
            counts["low_mean"] += 1
            continue
        result.append(
            {
                "bbox": [x.start, y.start, x.stop, y.stop],
                "score": score,
                "status": "via" if score >= CFG["component_via_mean_probability"] else "unknown",
            }
        )
    return result, counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="result")
    parser.add_argument("--model", help="Existing ilp: skip training and rerun predictions")
    opts = parser.parse_args()
    out = BASE / opts.output
    out.mkdir(parents=True, exist_ok=True)
    if (out / "predictions.json").exists():
        raise RuntimeError("Preserve completed predictions: select a fresh --output")
    data = json.loads((BASE.parent / "dataset/dataset.json").read_text())
    derived = out / "gray"
    derived.mkdir(exist_ok=True)
    timing = {
        "clock": "time.perf_counter seconds",
        "full_original_work_wall_seconds": None,
        "original_setup_annotation_seconds": None,
        "reason": "Prior quota interruption; original active duration not recoverable",
        "batch_repeats": [],
        "model_reused": bool(opts.model),
    }
    start = time.perf_counter()
    model = Path(opts.model).resolve() if opts.model else out / "model.ilp"
    if model.exists() and not opts.model:
        raise RuntimeError("Model already exists; use --model or fresh output")
    args = ["--headless", "--logfile=" + str(out / "ilastik.log")]
    args += (
        ["--project=" + str(model), "--readonly"]
        if opts.model
        else ["--new_project=" + str(model), "--workflow=Pixel Classification"]
    )
    shell = app.main(app.parse_args(args))
    workflow = shell.workflow
    pc = workflow.pcApplet.topLevelOperator
    timing["app_start_seconds"] = time.perf_counter() - start
    if not opts.model:
        start = time.perf_counter()
        train_paths = [prepare(row, derived) for row in data["train"]]
        selection = workflow.dataSelectionApplet.topLevelOperator
        selection.DatasetGroup.resize(len(train_paths))
        for i, path in enumerate(train_paths):
            selection.DatasetGroup[i][0].setValue(FilesystemDatasetInfo(filePath=path))
        features = workflow.featureSelectionApplet.topLevelOperator
        features.Scales.setValue(CFG["scales"])
        features.FeatureIds.setValue(CFG["features"])
        features.SelectionMatrix.setValue(
            np.ones((len(CFG["features"]), len(CFG["scales"])), dtype=bool)
        )
        features.ComputeIn2d.setValue([True] * len(CFG["scales"]))
        pc.ClassifierFactory.setValue(ParallelVigraRfLazyflowClassifierFactory(CFG["trees"]))
        pc.LabelNames.setValue([CFG["labels"]["1"], CFG["labels"]["2"]])
        for i, row in enumerate(data["train"]):
            labels = np.asarray(Image.open(BASE / "labels" / (row["id"] + "-labels.png")))
            assert set(np.unique(labels)) <= {0, 1, 2}
            tagged = vigra.taggedView(labels[:, :, None], "yxc")
            slot = pc.LabelInputs[i]
            aligned = tagged.withAxes(*slot.meta.getAxisKeys())
            assert aligned.shape == slot.meta.shape
            slot[tuple(slice(0, n) for n in aligned.shape)] = np.asarray(aligned)
        timing["training_input_and_project_setup_seconds"] = time.perf_counter() - start
        start = time.perf_counter()
        pc.FreezePredictions.setValue(False)
        classifier = pc.Classifier.value
        timing["feature_and_rf_training_seconds"] = time.perf_counter() - start
        timing["classifier_type"] = type(classifier).__name__
        start = time.perf_counter()
        shell.projectManager.saveProject()
        timing["model_save_seconds"] = time.perf_counter() - start
    start = time.perf_counter()
    test_paths = [prepare(row, derived) for row in data["test"]]
    timing["test_input_preparation_seconds"] = time.perf_counter() - start
    workflow.dataExportApplet.topLevelOperator.InputSelection.setValue(0)
    baseline = None
    for repeat in range(CFG["batch_repeats"]):
        start = time.perf_counter()
        arrays = workflow.batchProcessingApplet.run_export(
            [{"Raw Data": FilesystemDatasetInfo(filePath=path)} for path in test_paths],
            export_to_array=True,
        )
        elapsed = time.perf_counter() - start
        assert len(arrays) == len(data["test"]) == 7
        # Each run_export builds and removes batch lanes; this measures real predictions,
        # feature extraction and batch plumbing with the same trained classifier.
        timing["batch_repeats"].append({"repeat": repeat + 1, "seconds": elapsed})
        if baseline is None:
            baseline = [np.asarray(a).copy() for a in arrays]
        else:
            assert all(np.array_equal(a, b) for a, b in zip(arrays, baseline, strict=True))
        dump(out / "timing.json", timing)
    start = time.perf_counter()
    images = []
    for row, array in zip(data["test"], baseline, strict=True):
        array = np.squeeze(array)
        assert array.shape == (128, 80, 2), array.shape
        assert np.isfinite(array).all() and np.allclose(array.sum(axis=-1), 1, atol=1e-5)
        p = array[..., 0]
        q = np.clip(p.astype(np.float64), 1e-12, 1 - 1e-12)
        entropy = -(q * np.log2(q) + (1 - q) * np.log2(1 - q))
        np.save(out / (row["id"] + "-probability.npy"), p)
        np.save(out / (row["id"] + "-entropy.npy"), entropy)
        Image.fromarray(np.uint8(np.clip(p, 0, 1) * 255)).save(
            out / (row["id"] + "-probability.png")
        )
        Image.fromarray(np.uint8(entropy * 255)).save(out / (row["id"] + "-entropy.png"))
        boxes, rejected = candidates(p)
        images.append(
            {
                "id": row["id"],
                "candidates": boxes,
                "discard_counts": rejected,
                "note": (
                    "Appearance candidates only; "
                    "no detection does not establish physical absence."
                ),
            }
        )
    dump(out / "predictions.json", {"images": images})
    timing["export_and_postprocess_seconds"] = time.perf_counter() - start
    timing["repeat_predictions_bitwise_equal"] = True
    timing["model_sha256"] = hashlib.sha256(model.read_bytes()).hexdigest()
    dump(out / "timing.json", timing)
    shell.closeCurrentProject()
    print("COMPLETE", out, flush=True)


if __name__ == "__main__":
    main()
