"""Batch six existing M3 traces and source-bound extent candidates; project venv required."""

import copy
import hashlib
import importlib.util
import json
import time
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path.cwd()
OUT = ROOT / "runs/batch-production-20261109"
B = ROOT / "benchmarks/batch-production-v1"
B.mkdir(exist_ok=True)
if (B / "sample.json").exists():
    raise RuntimeError("Frozen batch exists; select new OUT and B paths before rerun")


def read(p):
    return json.loads(Path(p).read_text())


def put(p, d):
    Path(p).write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n")


def ref(p):
    p = Path(p)
    return {"path": str(p.relative_to(ROOT)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


t = time.perf_counter()
modpath = ROOT / "runs/batch-tracing-comparison-20261106/algorithm/run.py"
sp = importlib.util.spec_from_file_location("ridge", modpath)
m = importlib.util.module_from_spec(sp)
sp.loader.exec_module(m)
photo = ROOT / "data/test_chip/tile_full/m3.jpg"
bounds = [50, 2180, 5101, 2460]
im = Image.open(photo).crop(bounds)
gray = np.asarray(im.convert("L"))
seeds = [2330, 2350, 2369, 2391, 2407, 2427]
seed_x = 200
right = m.trace(gray, [y - 2180 for y in seeds], seed_x, 5050)
left = m.trace(gray[:, ::-1], [y - 2180 for y in seeds], 5050 - seed_x, 5050)
tracks = []
for i, (a, b) in enumerate(zip(left, right, strict=True)):
    pts = [[5100 - x, y + 2180] for x, y in a["points"]][::-1] + [
        [x + 50, y + 2180] for x, y in b["points"]
    ][1:]
    tracks.append(
        {
            "id": f"C-M3-M{i + 1:02}",
            "points": pts,
            "end_states": ["scope_exit_not_physical_end"] * 2,
            "unknown_spans": a["unknown_spans"] + b["unknown_spans"],
        }
    )
xs = np.arange(50, 5101)
ys = np.array([np.interp(xs, *np.array(t["points"]).T) for t in tracks])
assert np.diff(ys, axis=0).min() > 0
put(
    B / "traces.json",
    {
        "actor": "AI_algorithm_candidate",
        "photo": ref(photo),
        "bounds": bounds,
        "algorithm": ref(modpath),
        "parameters": m.PARAMS,
        "tracks": tracks,
        "recognition_seconds": time.perf_counter() - t,
        "minimum_interline_gap_px": float(np.diff(ys, axis=0).min()),
    },
)
s = read(ROOT / "benchmarks/w34-left-m2-v1/sample.json")
old = copy.deepcopy(s)
ledger = read(ROOT / s["local_part_source_evidence"]["path"])
ledger["date"] = "2026-11-09"
ledger["reason"] = (
    "Batch source-bound outward extension of six existing M3 metals; "
    "no native anchor or interface edits."
)
changes = []
for tr in tracks:
    f = next(f for f in s["features_by_layer"]["M3"] if f["id"] == tr["id"])
    y = f["design_path"][0][1]
    half = f["design_width"] / 2
    for side, db, xrange in [
        ("WEST", [-2760, y - half, -2626, y + half], [50, 250]),
        ("EAST", [676, y - half, 2110, y + half], [3670, 5100]),
    ]:
        pid = "BATCH-20261109-" + side
        pts = [p for p in tr["points"] if xrange[0] <= p[0] <= xrange[1]]
        f.setdefault("local_parts", []).append(
            {
                "id": pid,
                "bounds": db,
                "basis": (
                    "Same-frame traced outward continuation; "
                    "orthogonal relative design, not pixel projection."
                ),
            }
        )
        ledger["parts"].append(
            {
                "metal_id": f["id"],
                "part_id": pid,
                "source_frame": "m3",
                "source_photo": ref(photo),
                "native_scope_bounds": bounds,
                "native_path": pts,
                "design_bounds": db,
                "source_role": "AI_OBSERVED_SAME_LAYER_CONTINUATION",
                "geometry_human_approved": False,
                "native_width_measured": False,
                "precise_projection_qualified": False,
                "scope_exit": {"state": "scope_exit_not_physical_end", "physical_end": False},
            }
        )
    changes.append(
        {
            "id": f["id"],
            "native_anchor_preserved": True,
            "old_footprint_preserved": True,
            "new_parts": ["BATCH-20261109-WEST", "BATCH-20261109-EAST"],
        }
    )
put(B / "local-parts-ledger.json", ledger)
s["local_part_source_evidence"] = ref(B / "local-parts-ledger.json")
s["canvas_bounds"] = [-2780, 0, 2130, 1440]
put(B / "sample.json", s)
request = read(ROOT / "benchmarks/w34-left-m2-v1/next-request.json")
for k in [
    "added_metal_ids",
    "added_interface_ids",
    "extension_evidence",
    "parent",
    "allowed_changed_ids",
    "revision_evidence",
]:
    request.pop(k, None)
request["sample"] = ref(B / "sample.json")
request["parent"] = ref(ROOT / "docs/assets/w34-left-m2-v1/work/manifest.json")
request["allowed_changed_ids"] = [t["id"] for t in tracks]
put(
    B / "revision-evidence.json",
    {
        "actor": "AI",
        "reason": ledger["reason"],
        "geometry_human_approved": False,
        "sources": {"traces": ref(B / "traces.json"), "ledger": ref(B / "local-parts-ledger.json")},
        "changes": changes,
    },
)
request["revision_evidence"] = ref(B / "revision-evidence.json")
request["limits"].append(
    "Batch six M3 outward extents only; L01 M3 carrier remains unknown, "
    "no new vias or connections. Native x50 and x5100 are scope limits, "
    "not physical endpoints."
)
put(B / "request.json", request)
# One view per group plus whole traced stripe; no repeated per-line page builds.
colors = ["#ff4040", "#00ffff", "#ffff00", "#ff40ff", "#00ff40", "#4080ff"]
for name, box in [
    ("west", [50, 2220, 550, 2460]),
    ("east", [3600, 2160, 5180, 2410]),
    ("overview", bounds),
]:
    raw = Image.open(photo).crop(box)
    mark = raw.copy()
    d = ImageDraw.Draw(mark)
    for tr, c in zip(tracks, colors, strict=True):
        d.line([(x - box[0], y - box[1]) for x, y in tr["points"]], fill=c, width=1)
        x = max(box[0] + 8, 50)
        y = float(np.interp(x, *np.array(tr["points"]).T))
        d.text((x - box[0], y - box[1] - 11), tr["id"], fill=c)
    raw.save(OUT / f"{name}-raw.png")
    mark.save(OUT / f"{name}-marked.png")
    panel = Image.new("RGB", (raw.width, raw.height * 2 + 22), "white")
    panel.paste(raw, (0, 22))
    panel.paste(mark, (0, raw.height + 22))
    ImageDraw.Draw(panel).text(
        (5, 4), "SOURCE / CANDIDATE: same native pixels; crop exits are not endpoints", fill="black"
    )
    panel.save(OUT / f"{name}-comparison.png")
put(
    OUT / "build-timing.json",
    {
        "build_seconds": time.perf_counter() - t,
        "candidate_ready_utc": datetime.now(UTC).isoformat(),
        "unchanged_native_anchors": all(
            a["native_path"] == b["native_path"]
            for a, b in zip(
                old["features_by_layer"]["M3"], s["features_by_layer"]["M3"], strict=True
            )
        ),
    },
)
print("Six traces and 12 extent candidates ready", read(B / "traces.json")["recognition_seconds"])
