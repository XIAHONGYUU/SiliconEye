import copy
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path.cwd()
B = ROOT / "benchmarks/batch-production-v1"
OUT = ROOT / "runs/batch-production-20261109"


def read(p):
    return json.loads(Path(p).read_text())


def put(p, d):
    Path(p).write_text(json.dumps(d, ensure_ascii=False, indent=2) + "\n")


def ref(p):
    p = Path(p)
    return {"path": str(p.relative_to(ROOT)), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


parent = ROOT / "docs/assets/w34-left-m2-v1/work/manifest.json"
request = read(parent.parent / "request.json")
sample = read(ROOT / request["sample"]["path"])
for side, after in [("left", [-2780, 0, 780, 1440]), ("right", [-2780, 0, 2130, 1440])]:
    before = sample["canvas_bounds"]
    beforewh = sample["canvas_wh"]
    sample = copy.deepcopy(sample)
    sample["canvas_bounds"] = after
    sample["canvas_wh"] = [after[2] - after[0], after[3] - after[1]]
    for k in [
        "added_metal_ids",
        "added_interface_ids",
        "extension_evidence",
        "interface_extension_evidence",
        "allowed_changed_ids",
        "revision_evidence",
        "canvas_extension_evidence",
        "resolved_limits",
    ]:
        request.pop(k, None)
    request["reviews"] = []
    request["parent"] = ref(parent)
    put(B / f"canvas-{side}-sample.json", sample)
    request["sample"] = ref(B / f"canvas-{side}-sample.json")
    put(
        B / f"canvas-{side}-evidence.json",
        {
            "kind": "conductive_canvas_extension",
            "actor": "AI",
            "reason": "Outward viewport for batch M3 extents; no existing site changes.",
            "parent": ref(parent),
            "from_canvas_wh": beforewh,
            "to_canvas_wh": sample["canvas_wh"],
            "from_canvas_bounds": before,
            "to_canvas_bounds": after,
            "direction": side.upper() + "_ONLY",
            "origin_xy": [0, 0],
            "scale_xy": [1, 1],
            "translation_xy": [0, 0],
            "geometry_human_approved": False,
        },
    )
    request["canvas_extension_evidence"] = ref(B / f"canvas-{side}-evidence.json")
    put(B / f"canvas-{side}-request.json", request)
    subprocess.run(
        [
            ".venv/bin/python",
            "-m",
            "silicon_eye.conductive_workflow",
            "--request",
            str(B / f"canvas-{side}-request.json"),
            "--output",
            str(OUT / f"canvas-{side}"),
        ],
        check=True,
    )
    parent = OUT / f"canvas-{side}/manifest.json"
    request = read(parent.parent / "request.json")
s = read(B / "sample.json")
s["canvas_wh"] = [4910, 1440]
put(B / "sample.json", s)
req = read(B / "request.json")
req["sample"] = ref(B / "sample.json")
req["parent"] = ref(parent)
put(B / "request.json", req)
subprocess.run(
    [
        ".venv/bin/python",
        "-m",
        "silicon_eye.conductive_workflow",
        "--request",
        str(B / "request.json"),
        "--output",
        str(OUT / "work-final"),
    ],
    check=True,
)
