"""Compare frozen candidate centerlines. Run with project .venv Python; numpy/Pillow required."""

import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
REF = json.loads((ROOT / "judge/reference.json").read_text())
PROTOCOL = json.loads((ROOT / "protocol.json").read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    results = {
        "reference_status": REF["status"],
        "reference_sha256": sha(ROOT / "judge/reference.json"),
        "source_sha256_match": sha(Path(PROTOCOL["source"])) == PROTOCOL["sha256"],
        "metric_units": "native pixels; vertical distance at 35 historical sample columns",
        "branches": {},
    }
    source = Image.open(PROTOCOL["source"]).convert("RGB")
    crop = PROTOCOL["crop"]
    panels = []
    for branch in ("traditional", "algorithm"):
        path = ROOT / branch / "geometry.json"
        geo = json.loads(path.read_text())
        tracks = {t["id"]: t for t in geo["tracks"]}
        b = {
            "geometry_sha256": sha(path),
            "track_count": len(geo["tracks"]),
            "unique_ids": len(tracks),
            "missing_ids": sorted(set(PROTOCOL["ids"]) - set(tracks)),
            "extra_ids": sorted(set(tracks) - set(PROTOCOL["ids"])),
            "tracks": [],
            "timing": json.loads((ROOT / branch / "timing.json").read_text()),
        }
        all_errors, heldout_errors, all_ys = [], [], []
        valid_all = True
        xgrid = np.arange(250, 3651)
        panel = source.crop(tuple(crop))
        draw = ImageDraw.Draw(panel)
        for r in REF["tracks"]:
            if r["id"] not in tracks:
                valid_all = False
                continue
            t = tracks[r["id"]]
            pts = np.asarray(t["points"], dtype=float)
            valid = (
                pts.ndim == 2
                and pts.shape[1] == 2
                and len(pts) >= 2
                and np.isfinite(pts).all()
                and np.all(np.diff(pts[:, 0]) > 0)
            )
            item = {
                "id": r["id"],
                "point_count": len(pts),
                "finite_strict_monotonic": bool(valid),
                "unknown_spans": t.get("unknown_spans", []),
            }
            if not valid:
                valid_all = False
                b["tracks"].append(item)
                continue
            rp = np.asarray(r["points"], dtype=float)
            covered = (rp[:, 0] >= pts[0, 0]) & (rp[:, 0] <= pts[-1, 0])
            errors = abs(np.interp(rp[covered, 0], pts[:, 0], pts[:, 1]) - rp[covered, 1])
            all_errors.extend(errors.tolist())
            heldout_errors.extend(errors[rp[covered, 0] != 250].tolist())
            item.update(
                {
                    "x_range": [float(pts[0, 0]), float(pts[-1, 0])],
                    "full_x_coverage": bool(pts[0, 0] <= 250 and pts[-1, 0] >= 3650),
                    "reference_samples_covered": int(covered.sum()),
                    "mean_error": float(np.mean(errors)),
                    "median_error": float(np.median(errors)),
                    "max_error": float(np.max(errors)),
                    "within_2px": int((errors <= 2).sum()),
                    "within_4px": int((errors <= 4).sum()),
                }
            )
            all_ys.append(np.interp(xgrid, pts[:, 0], pts[:, 1]))
            draw.line(
                [(float(x - crop[0]), float(y - crop[1])) for x, y in pts],
                fill=(255, 40, 40),
                width=1,
            )
            b["tracks"].append(item)
        if all_errors:
            e = np.asarray(all_errors)
            b["aggregate"] = {
                "sample_count": len(e),
                "mean_error": float(e.mean()),
                "median_error": float(np.median(e)),
                "max_error": float(e.max()),
                "within_2px_count": int((e <= 2).sum()),
                "within_4px_count": int((e <= 4).sum()),
            }
        if heldout_errors:
            e = np.asarray(heldout_errors)
            b["heldout_excluding_six_shared_seeds"] = {
                "sample_count": len(e),
                "mean_error": float(e.mean()),
                "median_error": float(np.median(e)),
                "max_error": float(e.max()),
                "within_2px_count": int((e <= 2).sum()),
                "within_4px_count": int((e <= 4).sum()),
            }
        if valid_all and len(all_ys) == 6:
            ys = np.asarray(all_ys)
            refys = np.asarray(
                [
                    np.interp(xgrid, np.array(r["points"])[:, 0], np.array(r["points"])[:, 1])
                    for r in REF["tracks"]
                ]
            )
            nearest = np.argmin(abs(ys[:, None, :] - refys[None, :, :]), axis=1)
            b["ordering"] = {
                "nonpositive_adjacent_gap_columns": int(
                    (np.diff(ys, axis=0) <= 0).any(axis=0).sum()
                ),
                "minimum_adjacent_gap_px": float(np.diff(ys, axis=0).min()),
                "nearest_reference_identity_mismatch_track_columns": int(
                    (nearest != np.arange(6)[:, None]).sum()
                ),
                "total_track_columns": int(ys.size),
                "note": "Reference-based identity check, not independent connectivity proof.",
            }
        panel.save(ROOT / "judge" / f"{branch}-overlay.png")
        panels.append((branch, panel))
        results["branches"][branch] = b
    combined = Image.new("RGB", (crop[2] - crop[0], 2 * (crop[3] - crop[1] + 24)), "white")
    d = ImageDraw.Draw(combined)
    for i, (name, panel) in enumerate(panels):
        y = i * (panel.height + 24)
        d.text((5, y + 5), name, fill="black")
        combined.paste(panel, (0, y + 24))
    combined.save(ROOT / "judge/comparison.png")
    for x in REF["visual_check_x"]:
        rp = [
            np.interp(x, np.array(r["points"])[:, 0], np.array(r["points"])[:, 1])
            for r in REF["tracks"]
        ]
        box = (x - 50, int(min(rp)) - 18, x + 50, int(max(rp)) + 18)
        canv = Image.new("RGB", (600, (box[3] - box[1]) * 3 + 24), "white")
        cd = ImageDraw.Draw(canv)
        for j, branch in enumerate(("traditional", "algorithm")):
            im = source.crop(box)
            d = ImageDraw.Draw(im)
            data = json.loads((ROOT / branch / "geometry.json").read_text())
            for t in data["tracks"]:
                pts = np.array(t["points"])
                xx = np.arange(max(box[0], pts[0, 0]), min(box[2], pts[-1, 0] + 1))
                yy = np.interp(xx, pts[:, 0], pts[:, 1])
                d.line(
                    [(float(a - box[0]), float(b - box[1])) for a, b in zip(xx, yy, strict=True)],
                    fill="red",
                    width=1,
                )
            im = im.resize((300, im.height * 3))
            canv.paste(im, (j * 300, 24))
            cd.text((j * 300 + 5, 5), branch, fill="black")
        canv.save(ROOT / "judge" / f"comparison-x{x}.png")
    initial_path = ROOT / "algorithm/geometry-initial.json"
    initial = json.loads(initial_path.read_text())
    grid = np.arange(250, 3651)
    ys, err = [], []
    for t, r in zip(initial["tracks"], REF["tracks"], strict=True):
        pts, rp = np.array(t["points"]), np.array(r["points"])
        ys.append(np.interp(grid, pts[:, 0], pts[:, 1]))
        err.extend(abs(np.interp(rp[1:, 0], pts[:, 0], pts[:, 1]) - rp[1:, 1]))
    ys = np.array(ys)
    refs = np.array(
        [
            np.interp(grid, np.array(r["points"])[:, 0], np.array(r["points"])[:, 1])
            for r in REF["tracks"]
        ]
    )
    nearest = np.argmin(abs(ys[:, None, :] - refs[None, :, :]), axis=1)
    results["algorithm_initial_failure"] = {
        "sha256": sha(initial_path),
        "heldout_sample_count": len(err),
        "mean_error": float(np.mean(err)),
        "max_error": float(np.max(err)),
        "within_4px_count": int((np.array(err) <= 4).sum()),
        "nonpositive_adjacent_gap_columns": int((np.diff(ys, axis=0) <= 0).any(axis=0).sum()),
        "nearest_reference_identity_mismatch_track_columns": int(
            (nearest != np.arange(6)[:, None]).sum()
        ),
        "total_track_columns": int(ys.size),
        "endpoints": [t["points"][-1] for t in initial["tracks"]],
    }
    (ROOT / "judge/evaluation.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({k: v.get("aggregate") for k, v in results["branches"].items()}, indent=2))


if __name__ == "__main__":
    main()
