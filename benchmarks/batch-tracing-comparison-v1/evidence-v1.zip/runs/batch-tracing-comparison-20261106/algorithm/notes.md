# Automatic seeded ridge tracing pilot

Method: Gaussian bright-ridge response (vertical fine scale 1 px minus background scale 6 px; horizontal smoothing 3 px), followed by dynamic programming through local ridge maxima with ±1 px support. Sample x every 4 px; adjacent graph nodes may move at most 3 px vertically. Six seeds are the only manually supplied path coordinates. This is ridge/graph tracing, not an FLD implementation. CPU only; no new packages.

Initial unconstrained intensity DP merged several paths onto brighter neighbors. Preserved geometry-initial.json records this failure. One correction restricted graph nodes to local ridge support and changed max displacement/movement penalty; final six paths remain separate. No path coordinates were manually corrected. Initial computation timings were 0.430064 s, with five repeats 0.338344/0.326236/0.330756/0.334981/0.331403 s; these belong to the failed version and must not be used as final performance.

Final execution.json records six invocations including source image decode, crop, ridge filtering and all six paths. It excludes output PNG/JSON serialization and Python process startup. Wall-clock trial timing includes implementation, model reasoning/tool delays, failure diagnosis, one correction, inspection, checks and documentation. This first implementation is not equivalent to future repeat usage.

Visual inspection of full overlay and enlarged middle crop found the six lines follow separate bright bands. This is AI observation, not ground truth. A two-parallel-line synthetic test recovered known slanted centerline within 0.48 px. Minimum final pairwise row separation is 14 px. No low-response samples under the declared 0.12 threshold; this does not prove no physical ambiguity.

Limits: assumes monotone x paths, shallow slopes, bright narrow ridges and reliable seeds; cannot handle arbitrary bends, crossings, breaks or vias. No cross-layer connectivity, polygons, widths or netlist. Invalid/missing supported graph paths raise an error. The test region itself is easy, long, near-parallel wiring; no general full-chip speed claim.

Run `.venv/bin/python runs/batch-tracing-comparison-20261106/algorithm/run.py`. This regenerates final geometry and execution timing, preserves initial geometry if already present. Original trial timing is in timing.json.
