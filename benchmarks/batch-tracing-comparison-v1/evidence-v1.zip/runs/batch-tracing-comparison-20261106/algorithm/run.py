"""Seeded bright-ridge DP pilot; run with project .venv Python, requires scipy/Pillow/numpy."""

import hashlib
import json
import time
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, maximum_filter1d

HERE = Path(__file__).resolve().parent
PROTOCOL = HERE.parent / "protocol.json"
PARAMS = dict(
    step_x=4,
    sigma_y=1.0,
    sigma_x=3.0,
    background_sigma_y=6.0,
    max_dy=3,
    movement_penalty=0.3,
    unknown_ridge_threshold=0.12,
)


def trace(gray, seeds, x_start, x_end):
    smooth = gaussian_filter(gray.astype(float), (PARAMS["sigma_y"], PARAMS["sigma_x"]))
    ridge = smooth - gaussian_filter(smooth, (PARAMS["background_sigma_y"], 0))
    scale = max(float(np.percentile(np.abs(ridge), 95)), 1.0)
    ridge = ridge / scale
    xs = np.arange(x_start, x_end + 1, PARAMS["step_x"])
    if xs[-1] != x_end:
        xs = np.append(xs, x_end)
    height = gray.shape[0]
    peaks = (ridge == maximum_filter1d(ridge, size=5, axis=0)) & (ridge > 0.12)
    allowed = maximum_filter1d(peaks.astype(int), size=3, axis=0).astype(bool)
    tracks = []
    for sy in seeds:
        score = np.full(height, -1e20)
        score[sy] = 0
        parents = np.zeros((len(xs), height), dtype=np.int16)
        ys_all = np.arange(height)
        for k, x in enumerate(xs[1:], 1):
            offsets = np.arange(-PARAMS["max_dy"], PARAMS["max_dy"] + 1)
            choices = np.full((len(offsets), height), -1e20)
            for j, delta in enumerate(offsets):
                prev = ys_all + delta
                valid = (prev >= 0) & (prev < height)
                choices[j, valid] = score[prev[valid]] - PARAMS["movement_penalty"] * abs(delta)
            best = np.argmax(choices, axis=0)
            parents[k] = np.clip(ys_all + offsets[best], 0, height - 1)
            score = choices[best, ys_all] + ridge[:, x]
            score[~allowed[:, x]] = -1e20
            if score.max() < -1e10:
                raise RuntimeError(f"No supported ridge path for seed {sy}, x={x}")
        ys = np.zeros(len(xs), dtype=int)
        ys[-1] = np.argmax(score)
        for k in range(len(xs) - 1, 0, -1):
            ys[k - 1] = parents[k, ys[k]]
        values = ridge[ys, xs]
        low = values < PARAMS["unknown_ridge_threshold"]
        spans = []
        start = None
        for k, bad in enumerate(np.r_[low, False]):
            if bad and start is None:
                start = k
            if not bad and start is not None:
                spans.append([int(xs[start]), int(xs[k - 1])])
                start = None
        tracks.append(
            dict(
                points=np.column_stack((xs, ys)).tolist(),
                unknown_spans=spans,
                ridge_min=float(values.min()),
                ridge_median=float(np.median(values)),
            )
        )
    return tracks


def compute(protocol):
    started = time.perf_counter()
    image = Image.open(protocol["source"]).convert("RGB")
    x0, y0, x1, y1 = protocol["crop"]
    crop = image.crop((x0, y0, x1, y1))
    gray = np.asarray(crop.convert("L"))
    traces = trace(
        gray,
        [s[1] - y0 for s in protocol["seeds"]],
        protocol["x_range"][0] - x0,
        protocol["x_range"][1] - x0,
    )
    for ident, tr in zip(protocol["ids"], traces, strict=True):
        tr["id"] = ident
        tr["points"] = [[x + x0, y + y0] for x, y in tr["points"]]
        tr["unknown_spans"] = [[a + x0, b + x0] for a, b in tr["unknown_spans"]]
    return (
        dict(
            tracks=traces,
            status="AI_candidate",
            params=PARAMS,
            source_sha256=protocol["sha256"],
            transform="native identity",
        ),
        crop,
        time.perf_counter() - started,
    )


def synthetic_check():
    yy, xx = np.mgrid[:100, :401]
    center = 65 - 0.04 * xx
    gray = 30 + 140 * np.exp(-0.5 * ((yy - center) / 1.7) ** 2)
    gray += 120 * np.exp(-0.5 * ((yy - center + 17) / 1.7) ** 2)
    t = trace(gray, [65], 0, 400)[0]
    errors = [abs(y - (65 - 0.04 * x)) for x, y in t["points"]]
    assert max(errors) <= 1.0, max(errors)
    assert t["points"][0] == [0, 65]
    return {"max_centerline_error_px": max(errors), "parallel_line_jump": False}


def main():
    p = json.loads(PROTOCOL.read_text())
    assert hashlib.sha256(Path(p["source"]).read_bytes()).hexdigest() == p["sha256"]
    synthetic = synthetic_check()
    results = []
    first = None
    for _ in range(6):
        g, crop, elapsed = compute(p)
        results.append(elapsed)
        if first is None:
            first = g
    if not (HERE / "geometry-initial.json").exists():
        (HERE / "geometry-initial.json").write_text(json.dumps(first, indent=2))
    (HERE / "geometry.json").write_text(json.dumps(first, indent=2))
    overlay = crop.copy()
    d = ImageDraw.Draw(overlay)
    colors = ["#ff3333", "#33ff33", "#3399ff", "#ffcc00", "#ff33ff", "#00ffff"]
    x0, y0, _, _ = p["crop"]
    for tr, col in zip(first["tracks"], colors, strict=True):
        pts = [(x - x0, y - y0) for x, y in tr["points"]]
        d.line(pts, fill=col, width=2)
        d.text((pts[0][0] + 3, pts[0][1] - 10), tr["id"], fill=col)
    overlay.save(HERE / "overlay.png")
    (HERE / "execution.json").write_text(
        json.dumps(
            {
                "utc": datetime.now(UTC).isoformat(),
                "first_execution_seconds": results[0],
                "repeat_execution_seconds": results[1:],
                "repeat_median_seconds": float(np.median(results[1:])),
                "includes": (
                    "source decode/crop, ridge filtering, six DP traces, geometry assembly; "
                    "excludes JSON/PNG writing"
                ),
                "synthetic_check": synthetic,
            },
            indent=2,
        )
    )
    print(
        json.dumps(
            {
                "times": results,
                "synthetic": synthetic,
                "endpoints": [
                    [t["id"], t["points"][-1], len(t["unknown_spans"])] for t in first["tracks"]
                ],
            }
        )
    )


if __name__ == "__main__":
    main()
