# Traditional visual tracing trial

Six AI candidate centerlines were traced from the supplied seeds by visual examination of original-image crops. Nine manually chosen control points per track (54 total), joined by straight segments. No pixel sampling, thresholding, automatic peak detection or prior geometry was used. Full-width image broken into three overlapping-boundary strips and additional labelled column strips for reading native coordinates.

All three rendered overlays visually checked. No correction rounds; initial and final geometry are identical. No observed identity swap or ambiguous span at this viewing scale. Microtexture and broad bright ridges limit exact center estimates; paths are approximate AI observations, not dense human truth or electrical connectivity. Interpolation between sparse points can hide local curvature.

Timing includes reading the protocol/rules, generating viewing crops, visual interpretation, writing geometry/render script, rendering and checks. Rerender only replays authored geometry and must not be presented as repeat manual tracing speed. One repeat rendering took 1.513791553 seconds. No human annotation or human acceptance time measured.

Run `.venv/bin/python runs/batch-tracing-comparison-20261106/traditional/render.py` from repository root.
