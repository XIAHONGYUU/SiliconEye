"""Render manually inspected M3 centerlines. Run with project .venv Python; requires Pillow."""

import json
import time
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent


def main():
    start = time.perf_counter()
    protocol = json.loads((ROOT.parent / "protocol.json").read_text())
    geo = json.loads((ROOT / "geometry.json").read_text())
    box = protocol["crop"]
    im = Image.open(protocol["source"]).crop(tuple(box)).convert("RGB")
    draw = ImageDraw.Draw(im)
    colors = ["#ff4030", "#00ffff", "#ffff00", "#ff40ff", "#00ff40", "#4080ff"]
    for track, color in zip(geo["tracks"], colors, strict=True):
        points = [(x - box[0], y - box[1]) for x, y in track["points"]]
        draw.line(points, fill=color, width=1)
        for x, y in points:
            draw.ellipse((x - 2, y - 2, x + 2, y + 2), outline=color)
        draw.text((points[0][0], points[0][1] - 10), track["id"], fill=color)
    im.save(ROOT / "overlay.png")
    for i, (a, b) in enumerate([(200, 1400), (1400, 2600), (2600, 3700)]):
        im.crop((a - box[0], 0, b - box[0], box[3] - box[1])).resize(((b - a) * 2, 600)).save(
            ROOT / f"overlay-{i}.png"
        )
    print(json.dumps({"render_seconds": time.perf_counter() - start}))


if __name__ == "__main__":
    main()
